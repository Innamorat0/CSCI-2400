/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_232()
{
    return 2421727686U;
}

unsigned getval_182()
{
    return 3281031256U;
}

unsigned getval_274()
{
    return 3347662968U;
}

unsigned addval_377(unsigned x)
{
    return x + 3267856712U;
}

unsigned getval_136()
{
    return 1221993758U;
}

unsigned getval_124()
{
    return 3281031248U;
}

unsigned getval_383()
{
    return 2428995848U;
}

unsigned getval_245()
{
    return 3347662907U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_367()
{
    return 2430634312U;
}

void setval_138(unsigned *p)
{
    *p = 3524841865U;
}

unsigned addval_276(unsigned x)
{
    return x + 3225997705U;
}

unsigned addval_345(unsigned x)
{
    return x + 3375419785U;
}

unsigned addval_252(unsigned x)
{
    return x + 3380924811U;
}

unsigned getval_168()
{
    return 3526938251U;
}

void setval_297(unsigned *p)
{
    *p = 2425668233U;
}

unsigned addval_401(unsigned x)
{
    return x + 3531918985U;
}

void setval_371(unsigned *p)
{
    *p = 3284648585U;
}

void setval_199(unsigned *p)
{
    *p = 3353381192U;
}

void setval_315(unsigned *p)
{
    *p = 3372797579U;
}

void setval_449(unsigned *p)
{
    *p = 3384918665U;
}

void setval_351(unsigned *p)
{
    *p = 3281047177U;
}

unsigned addval_107(unsigned x)
{
    return x + 2497743176U;
}

unsigned getval_220()
{
    return 3677934025U;
}

unsigned addval_434(unsigned x)
{
    return x + 3383018121U;
}

unsigned getval_319()
{
    return 3767093322U;
}

void setval_215(unsigned *p)
{
    *p = 3682914697U;
}

unsigned addval_161(unsigned x)
{
    return x + 3286276424U;
}

unsigned addval_147(unsigned x)
{
    return x + 3676881545U;
}

unsigned getval_328()
{
    return 3281047181U;
}

unsigned getval_430()
{
    return 2430634344U;
}

unsigned getval_157()
{
    return 3380920969U;
}

unsigned addval_121(unsigned x)
{
    return x + 3674788233U;
}

unsigned addval_334(unsigned x)
{
    return x + 3286288712U;
}

void setval_135(unsigned *p)
{
    *p = 3268315517U;
}

void setval_283(unsigned *p)
{
    *p = 3230974601U;
}

unsigned addval_197(unsigned x)
{
    return x + 2429455839U;
}

unsigned getval_204()
{
    return 3536114057U;
}

void setval_193(unsigned *p)
{
    *p = 3531915913U;
}

unsigned getval_480()
{
    return 3353381192U;
}

void setval_290(unsigned *p)
{
    *p = 3525365387U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
